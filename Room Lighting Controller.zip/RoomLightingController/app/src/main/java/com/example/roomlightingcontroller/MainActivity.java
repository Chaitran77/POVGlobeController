package com.example.roomlightingcontroller;

import static android.Manifest.permission.BLUETOOTH_CONNECT;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import top.defaults.colorpicker.ColorPickerView;
import top.defaults.colorpicker.ColorObserver;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothSocket mmSocket;
    private BluetoothDevice mmDevice;

    private OutputStream BTOutStream;

    private TextView BTStateLbl;
    private Set<BluetoothDevice> pairedDevices;
    private ArrayAdapter<String> BTArrayAdapter;

    private int PERMISSION_ALL = 1;
    private String[] PERMISSIONS = {
            Manifest.permission.BLUETOOTH,
            BLUETOOTH_CONNECT
    };

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BTStateLbl = findViewById(R.id.BTStateLabel);

        // grant BT perms before subToPicker because user may interact with colour picker and trigger sendColour() without BT perms, causing errors
        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

        subToPicker();

    }

    void subToPicker() {
        ColorPickerView colourPickerView = findViewById(R.id.colorPicker);

        colourPickerView.setInitialColor(0x67200000);


        colourPickerView.subscribe((color, fromUser, shouldPropagate) -> {
            System.out.println(colourToHex(color));
            try {
                sendColour(colourToHex(color));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @SuppressLint("MissingPermission")
    public void showBTDialog(View v) {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
//        if (mBluetoothAdapter.isEnabled() == false)
//            mBluetoothAdapter.enable();

        final AlertDialog.Builder popDialog = new AlertDialog.Builder(this);
        final LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        final View Viewlayout = inflater.inflate(R.layout.bt_list, (ViewGroup) findViewById(R.id.bt_list));

        popDialog.setTitle("Paired Bluetooth Devices");
        popDialog.setView(Viewlayout);

        // create the arrayAdapter that contains the BTDevices, and set it to a ListView
        ListView myListView = (ListView) Viewlayout.findViewById(R.id.BTList);
        BTArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        myListView.setAdapter(BTArrayAdapter);

        // get paired devices
        pairedDevices = mBluetoothAdapter.getBondedDevices();

        // put each one into the adapter
        for (BluetoothDevice device : pairedDevices)
            BTArrayAdapter.add(device.getName() + "\n" + device.getAddress());

        myListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Button OK
        popDialog.setPositiveButton("Connect",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        try {
                            System.out.println(myListView.getCheckedItemPosition());
                            connectToBTDev(BTArrayAdapter.getItem(myListView.getCheckedItemPosition()));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        // Create popup and show
        popDialog.create();
        popDialog.show();

    }

    @SuppressLint({"SetTextI18n", "MissingPermission"})
    public void connectToBTDev(String deviceInfo) throws IOException {

        if (mBluetoothAdapter == null) {
            BTStateLbl.setText("No bluetooth adapter available");
        }

        if (!mBluetoothAdapter.isEnabled()) {
            System.out.println("HI");
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBluetooth);
        }

        for (BluetoothDevice device : pairedDevices) {
//                if(device.getName().equals("HC-06"))
            if (device.getAddress().equals(deviceInfo.split("\n")[1])) {
                System.out.println(deviceInfo.split("\n")[1]);
                System.out.println(device.getAddress());
                mmDevice = device;
                break;
            }
        }

        BTStateLbl.setText("Bluetooth Device Found");
        openBT();
    }

    @SuppressLint("MissingPermission")
    void openBT() {
        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID

        try {
            if (!hasPermissions(this, PERMISSIONS)) {
                ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
            }

            mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);
            mmSocket.connect();


            BTOutStream = mmSocket.getOutputStream();
            BTStateLbl.setText("Bluetooth Opened");
        } catch (IOException e) {
            BTStateLbl.setText("An error occurred :(");
        }


    }

    private void sendColour(String hexColour) throws IOException {
        //remember \0 to end string
        System.out.println(hexColour + '\0');
        if (BTOutStream != null) {
            BTOutStream.write(hexColour.getBytes());
        }
    }

    public void sendModeCode(View v) throws IOException {
        String code;
        if (v.getId() == R.id.continuousModeButton){
            code = "!C";
        } else {
            code = "!S";
        }

        //remember \0 to end string
        System.out.println("CODE " + code + '\0');
        if (BTOutStream != null) {
//              BTOutStream.write(("SOCO " + hexColour + '\0').getBytes());
            BTOutStream.write(code.getBytes());
        }
    }

    private String colourToHex(int colour) {
        int r = Color.red(colour);
        int g = Color.green(colour);
        int b = Color.blue(colour);
        return String.format(Locale.getDefault(), "#%02X%02X%02X", r, g, b);
    }
}